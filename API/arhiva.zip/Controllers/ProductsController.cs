using System;
using System.Collections.Generic;
using System.Linq;
using API.Data;
using API.Entities;
using Microsoft.AspNetCore.Mvc;

namespace API.Controllers
{
    [ApiController]
    [Route("api/products")]
    public class ProductsController : ControllerBase
    {
        private readonly DataContext context;
        public ProductsController(DataContext context)
        {
            this.context = context;
        }

        [HttpGet]
        public ActionResult<IEnumerable<Product>> Get(){
            return this.context.Products.ToList();
        }

        [HttpGet("{id}")]
        public ActionResult<Product> Get(int id){
            return this.context.Products.Find(id);
        }
        [HttpGet("valid")]
        //[Route("api/products/validProduct")]
        public ActionResult<IEnumerable<Product>> GetValid(){
            
            var timeString = DateTime.Now.ToString("hh:mm:ss");
            List<Product> validProducts = new List<Product>();

            foreach (var item in this.context.Products.ToList())
            {
                if (item.ValidTo == null)
                    validProducts.Add(item);
                else if ((item.ValidTo.Subtract(item.ValidFrom)).Days>0)
                    validProducts.Add(item);
                
            }
            return validProducts;

        }
        
        [HttpGet("sum")]
        public ActionResult<float> GetSum(){
            
            float sum=0;

            foreach (var item in this.context.Products.ToList())
            {
              sum += item.Price;
            }
            return sum;
        }
        [Route("api/products/valid/sum")]
        [HttpGet]
        public ActionResult<float> GetValidSum(){
            
            var timeString = DateTime.Now.ToString("hh:mm:ss");
            List<Product> validProducts = new List<Product>();
            float sum=0;

            foreach (var item in this.context.Products.ToList())
            {
                if (item.ValidTo == null){
                    validProducts.Add(item);
                    sum += item.Price;
                }
                else if ((item.ValidTo.Subtract(item.ValidFrom)).Days>0){
                    validProducts.Add(item);
                    sum += item.Price;
            }
                
            }
            return sum;
        }

    }
}